#ifndef WSPR_TX_SCHEDULER_H_
#define WSPR_TX_SCHEDULER_H_

int next_tx_state (int pctx);
int next_hopping_band();

#endif
