 gfortran -o wsprcode -fbounds-check wsprcode.f90 nhash.c
