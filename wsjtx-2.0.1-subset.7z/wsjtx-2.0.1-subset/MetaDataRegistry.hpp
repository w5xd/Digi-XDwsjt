#ifndef META_DATA_REGISTRY_HPP__
#define META_DATA_REGISTRY_HPP__

class QItemEditorFactory;

QItemEditorFactory * item_editor_factory ();
void register_types ();

#endif
