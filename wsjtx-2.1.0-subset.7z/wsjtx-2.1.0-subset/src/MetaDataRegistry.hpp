#ifndef META_DATA_REGISTRY_HPP__
#define META_DATA_REGISTRY_HPP__

void register_types ();

#endif
